import { useState } from 'react'
import Course from './components/Course'

/*
const Header = ({course}) => {
    return <h1>{course}</h1>
}

const Part = ({name, exercises}) => {

	return <p> {name} {exercises} </p>
}
const Content = ({parts}) => {
  console.log('parts:', parts)
  const list = parts.map((name) => (name))
  console.log('list:', list)
  console.log('name:', list.name)
  return (
     <>
	  {parts.map(part => <Part name={part.name} exercises={part.exercises}/>)}
	 </>	 
  )
}

const Total = ({parts}) => {
  
  // use .reduce instead of .forEach as .forEach is async, the sum would be 0
  const sum = parts.reduce((accumulator, part) => accumulator + part.exercises, 0)
  console.log('sum:', sum)
  return (
     <>
       <b> total of {sum} exercises</b>
     </>
  )
}

*/
const App = () => {
  const courses = [
	{
      name: 'Half Stack application development',
      id: 1,
      parts: [
        { 
          name: 'Fundamentals of React',
          exercises: 10,
	      id: 1
        },
        {
          name: 'Using props to pass data',
          exercises: 7,
	      id: 2
        },
        {
          name: 'State of a component',
          exercises: 14,
	      id: 3
        }, 
  	    {
          name: 'Redux',
          exercises: 11,
          id: 4
        }
      ]
    }, 
    {
      name: 'Node.js',
      id: 2,
      parts: [
        {
          name: 'Routing',
          exercises: 3,
          id: 1
        },
        {
          name: 'Middlewares',
          exercises: 7,
          id: 2
        }
      ]
    }
  ]
  

//  const Course = ({course}) => {
//	console.log('course:', course)
//	return (
//	  <>
//        <Header course={course.name} />
//	    <Content parts={course.parts} />
//	    <Total parts={course.parts} />
//	  </>
//	)
// }
	
  return (
    <div>
	   {courses.map(course => <Course course={course}/>)}
	</div>
  )
}
export default App
